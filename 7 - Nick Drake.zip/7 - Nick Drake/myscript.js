function init() {
    window.addEventListener('scroll', function(e){
        var distanceY = window.pageYOffset || document.documentElement.scrollTop,
            shrinkOn = 100,
            header = document.querySelector("header");
        if (distanceY > shrinkOn) {
            classie.add(header,"smaller");
            document.querySelector("#logo").innerHTML = "<a href=\"index.html\">/ / Nick Drake / /</a>";
        } else {
            if (classie.has(header,"smaller")) {
                classie.remove(header,"smaller");
                document.querySelector("#logo").innerHTML = "";
            }
        }
    });
}
window.onload = init();

//TUTORIAL FOUND AT: http://callmenick.com/post/animated-resizing-header-on-scroll